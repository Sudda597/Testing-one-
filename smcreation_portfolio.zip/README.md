# SmCreation Portfolio Website

This is a responsive portfolio website for **SmCreation** (Graphic Design & Android App Design).

## Features
- Responsive design
- Sections: Hero, Portfolio, Services, About, Contact
- WhatsApp and Email integration

## Setup
1. Download this repository or clone it.
2. Add your images inside the `assets/` folder.
3. Open `index.html` in your browser to view locally.

## GitHub Pages Deployment
1. Push this project to your GitHub repository.
2. Go to **Settings > Pages**.
3. Set the branch to `main` (root).
4. Your site will be live at: `https://yourusername.github.io/repository-name/`

---
© 2025 SmCreation
